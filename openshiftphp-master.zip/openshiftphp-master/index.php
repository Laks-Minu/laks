<html> 
	<head> 
	<title>PHP</title>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
	</head>

<body> 
	<h1>PHP 2022  Test</h1>
		<p><b> CITIBANK Session </b></p>
		<?php echo "The Current Date and yes las  Time is: <br />";
		echo date("g:i A l, F j Y.");?> </p>
	<h2>PHP Information VERSION 2 </h2> 
		<p> <?php phpinfo(); ?> </p> 
	</body> 
</html>
